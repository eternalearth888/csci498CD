How to build and run code in alamode.
-----------------------------------------------------------
1. $ make

2. For files
	$ ./cxxap < filename

3. For stdin
	$ ./cxaap
	-(write what you want)
	-when you are done writing, do (Ctrl+D) for it to recognize EOF

4. Edit the file IGNORE to change what is to be ignored

